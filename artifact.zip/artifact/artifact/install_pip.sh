cd pip_dependencies/
pip install cycler-0.11.0-py3-none-any.whl
pip install kiwisolver-1.3.2-cp38-cp38-manylinux_2_5_x86_64.manylinux1_x86_64.whl
pip install matplotlib-3.4.3-cp38-cp38-manylinux1_x86_64.whl
pip install mpmath-1.2.1-py3-none-any.whl
pip install numpy-1.21.3-cp38-cp38-manylinux_2_12_x86_64.manylinux2010_x86_64.whl
pip install Pillow-8.4.0-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl
pip install pyparsing-3.0.4-py3-none-any.whl
pip install python_dateutil-2.8.2-py2.py3-none-any.whl
pip install six-1.16.0-py2.py3-none-any.whl
pip install sympy-1.9-py3-none-any.whl
cd ..
